find ./examples -name "build*" | xargs rm -r
