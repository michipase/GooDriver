
#ifndef utils_h
#define utils_h

char *ftoa(char *a, double f, int precision);

void serialPrintf(const char *format, ...);

#endif
